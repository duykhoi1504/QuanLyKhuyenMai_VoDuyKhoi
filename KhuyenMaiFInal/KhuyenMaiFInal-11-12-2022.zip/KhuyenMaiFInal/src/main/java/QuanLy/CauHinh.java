/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuanLy;

import java.text.SimpleDateFormat;
import java.util.Scanner;

/**
 *
 * @author VoDuyKhoi
 */
public class CauHinh {

    public static final SimpleDateFormat f = new SimpleDateFormat("dd/MM/yyyy");
    public static final Scanner sc = new Scanner(System.in);

}
